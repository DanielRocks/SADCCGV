<?php
require_once("./authSession.php");
include_once("../modelos/cabecalho_login.html");
?>

    <div class="container">

      <div>
        <h1>Dados inválidos.</h1>
		<p class="lead">Verifique a senha e <a href="./cadastroUsuario.php"> tente novamente.</a></p>
        
	 </div>

	  
	  
    </div><!-- /.container -->

<?php
include_once("../modelos/rodape_login.html");
?>