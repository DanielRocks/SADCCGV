<?php
include_once("../modelos/cabecalho_login.html");

?>

    <div class="container">

      <div>
        <h1>Acesso negado.</h1>
		<p class="lead">Favor realizar o <a href="./index.php">login</a> no sistema.</p>
        
	 </div>

	  
	  
    </div><!-- /.container -->

<?php
include_once("../modelos/rodape_login.html");
?>