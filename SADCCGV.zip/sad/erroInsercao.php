<?php
require_once("./authSession.php");
include_once("../modelos/cabecalho_yearbook.html");
?>

    <div class="container">

      <div>
        <h1>Não foi possível realizar a inserção.</h1>
		<p class="lead"><a href="./inserir.php">Tente novamente.</a></p>
        
	 </div>

	  
	  
    </div><!-- /.container -->

<?php
include_once("../modelos/rodape_bdcompleto.html");
?>