<?php
/* Redirect browser */
header("Location: sad");
?>